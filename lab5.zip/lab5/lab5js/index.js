var express = require('express');
var bodyParser = require('body-parser');

var app = express();

var urlencodedParser = bodyParser.urlencoded({ extended: false });

app.set('view engine', 'ejs');

app.get('/message/create', function(req, res) {
  res.render('index');
});

app.post('/message/create/done', urlencodedParser, function(req, res) {
  console.log(req.body);
  res.render('info', {data: req.body});
});

app.listen(3000);
console.log('Running 3000 port...');
